#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI 3.14159265
#define Gezegen_Sayisi 8

void serbest_dusme(double *g, char **x);
void yukari_atis(double *g, char **x);
void agirlik_deneyi(double *g, char **x);
void potansiyel_enerji(double *g, char **x);
void hidrostatik_basinc(double *g, char **x);
void arsimet_kaldirma(double *g, char **x);
void basit_sarkac(double *g, char **x);
void sabit_ip_gerilmesi(double *g, char **x);
void asansor_deneyi(double *g, char **x);

int main() {
    char bilim_insani[50];
    int secim = 0;

    double g_ivmeleri[] = {3.7, 8.87, 9.81, 3.71, 24.79, 10.44, 8.69, 11.15};
    char *gezegen_adlari[] = {"Merkur", "Venus", "Dunya", "Mars", "Jupiter", "Saturn", "Uranus", "Neptun"};

    printf("UZAY SIMULASYONUNA HOS GELDINIZ\n");
    printf("Adinizi giriniz: ");
    scanf("%s", bilim_insani);

    while (1) {
        printf("\nSayin %s, lutfen yapmak istediginiz deneyi seciniz:\n", bilim_insani);
        printf("1. Serbest Dusme Deneyi\n");
        printf("2. Yukari Atis Deneyi\n");
        printf("3. Agirlik Deneyi\n");
        printf("4. Kutlecekimsel Potansiyel Enerji Deneyi\n");
        printf("5. Hidrostatik Basinc Deneyi\n");
        printf("6. Arsimet Kaldirma Kuvvveti Deneyi\n");
        printf("7. Basit Sarkac Periyodu Deneyi\n");
        printf("8. Sabit Ip Gerilmesi Deneyi\n");
        printf("9. Asansor Deneyi\n");
        printf("-1. Programi Kapat\n");
        printf("Seciminiz: ");
        scanf("%d", &secim);

        if (secim == -1) break;


        switch (secim) {
            case 1: serbest_dusme(g_ivmeleri, gezegen_adlari); break;
            case 2: yukari_atis(g_ivmeleri, gezegen_adlari); break;
            case 3: agirlik_deneyi(g_ivmeleri, gezegen_adlari); break;
            case 4: potansiyel_enerji(g_ivmeleri, gezegen_adlari); break;
            case 5: hidrostatik_basinc(g_ivmeleri, gezegen_adlari); break;
            case 6: arsimet_kaldirma(g_ivmeleri, gezegen_adlari); break;
            case 7: basit_sarkac(g_ivmeleri, gezegen_adlari); break;
            case 8: sabit_ip_gerilmesi(g_ivmeleri, gezegen_adlari); break;
            case 9: asansor_deneyi(g_ivmeleri, gezegen_adlari); break;
            default: printf("Gecersiz secim, tekrar deneyin.\n");
        }
    }

    printf("Program sonlandirildi. Iyi calismalarr %s.\n", bilim_insani);
    return 0;
}



void serbest_dusme(double *g, char **x) {
    double t, h;
    printf("Sureyi (t) saniye cinsinden giriniz: ");
    scanf("%le", &t);
    t = (t < 0) ? -t : t;

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        h = 0.5 * (*(g + i)) * t * t;
        printf("%s: Alinan yol h = %.2f metre\n", *(x + i), h);
    }
}

void yukari_atis(double *g, char **x) {
    double v0, hmax;
    printf("Ilk hizi (v0) m/s cinsinden giriniz: ");
    scanf("%le", &v0);
    v0 = (v0 < 0) ? -v0 : v0;

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        hmax = (v0 * v0) / (2 * (*(g + i)));
        printf("%s: Maksimum yukseklik hmax = %.2f metre\n", *(x + i), hmax);
    }
}

void agirlik_deneyi(double *g, char **x) {
    double m, G;
    printf("Kutleyi (m) kg cinsinden giriniz: ");
    scanf("%le", &m);
    m = (m < 0) ? -m : m;

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        G = m * (*(g + i));
        printf("%s: Agirlik G = %.2f Newton\n", *(x + i), G);
    }
}

void potansiyel_enerji(double *g, char **x) {
    double m, h, Ep;
    printf("Kutleyi (m) kg ve yuksekligi (h) metre giriniz: ");
    scanf("%le %le", &m, &h);
    m = (m < 0) ? -m : m;
    h = (h < 0) ? -h : h;

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        Ep = m * (*(g + i)) * h;
        printf("%s: Potansiyel Enerji Ep = %.2f Joule\n", *(x + i), Ep);
    }
}

void hidrostatik_basinc(double *g, char **x) {
    double rho, h, P;
    printf("Sivi yogunlugunu (rho) kg/m3 ve derinligi (h) metre giriniz: ");
    scanf("%le %le", &rho, &h);
    rho = (rho < 0) ? -rho : rho;
    h = (h < 0) ? -h : h;

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        P = rho * (*(g + i)) * h;
        printf("%s: Hidrostatik Basinc P = %.2f Pascal\n", *(x + i), P);
    }
}

void arsimet_kaldirma(double *g, char **x) {
    double rho, V, Fk;
    printf("Sivi yogunlugunu (rho) kg/m3 ve batan hacmi (V) m3 giriniz: ");
    scanf("%le %le", &rho, &V);
    rho = (rho < 0) ? -rho : rho;
    V = (V < 0) ? -V : V;

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        Fk = rho * (*(g + i)) * V;
        printf("%s: Kaldirma Kuvveti Fk = %.2f Newton\n", *(x + i), Fk);
    }
}

void basit_sarkac(double *g, char **x) {
    double L, T;
    printf("Sarkac uzunlugunu (L) metre cinsinden giriniz: ");
    scanf("%le", &L);
    L = (L < 0) ? -L : L;

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        T = 2 * PI * sqrt(L / (*(g + i)));
        printf("%s: Periyot T = %.2f saniye\n", *(x + i), T);
    }
}

void sabit_ip_gerilmesi(double *g, char **x) {
    double m, T;
    printf("Kutleyi (m) kg cinsinden giriniz: ");
    scanf("%le", &m);
    m = (m < 0) ? -m : m;

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        T = m * (*(g + i));
        printf("%s: Ip Gerilmesi T = %.2f Newton\n", *(x + i), T);
    }
}

void asansor_deneyi(double *g, char **x) {
    double m, a, N;
    int durum;
    printf("Kutleyi (m) kg ve asansor ivmesini (a) m/s2 giriniz: ");
    scanf("%le %le", &m, &a);
    m = (m < 0) ? -m : m;
    a = (a < 0) ? -a : a;

    printf("Durum seciniz:\n1. Yukari Hizlanan / Asagi Yavaslayan\n2. Asagi Hizlanan / Yukari Yavaslayan\nSecim: ");
    scanf("%d", &durum);

    for (int i = 0; i < Gezegen_Sayisi; i++) {
        if (durum == 1)
            N = m * ((*(g + i)) + a);
        else
            N = m * ((*(g + i)) - a);

        printf("%s: Etkin Agirlik N = %.2f Newton\n", *(x + i), N);
    }
}
